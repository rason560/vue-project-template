import Vue from 'vue'
import App from './App.vue'

import { Button, Field, Cell, CellGroup } from 'vant'
const vantComponents = { Button, Field, Cell, CellGroup }

Object.keys(vantComponents).forEach(key => {
  Vue.use(vantComponents[key])
})

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')
